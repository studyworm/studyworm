package com.mobis.as.mpsa.batch.ph;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class HdBatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
